SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(30) NOT NULL,
  `category` varchar(250) NOT NULL,
  `description` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `balance` float NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `description`, `status`, `balance`, `date_created`, `date_updated`) VALUES
(1, 'Main Budget', '&lt;p&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-size: 14px; text-align: justify;&quot;&gt;norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 1, 30555, '2024-05-06 12:21:36', '2024-05-06 12:36:10'),
(2, 'Maintenance', '&lt;p&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-size: 14px; text-align: justify;&quot;&gt;norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 1, 4700, '2024-05-06 12:21:36', '2024-05-06 12:36:10'),
(3, 'Electricity', '&lt;p&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-size: 14px; text-align: justify;&quot;&gt;norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 1, 5000, '2024-05-06 12:21:36', '2024-05-06 12:36:10'),
(4, 'Water', '&lt;p&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-size: 14px; text-align: justify;&quot;&gt;norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essaynorhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 1, 3000, '2024-05-06 12:21:36', '2024-05-06 12:36:10'),
(5, 'Others', '&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-size: 14px;&quot;&gt;norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay norhan macmod handsome essay&lt;/p&gt;', 1, 6000, '2024-05-06 12:21:36', '2024-05-06 12:36:10');

-- --------------------------------------------------------

--
-- Table structure for table `running_balance`
--

CREATE TABLE `running_balance` (
  `id` int(30) NOT NULL,
  `balance_type` tinyint(1) NOT NULL COMMENT '1=budget, 2=expense',
  `category_id` int(30) NOT NULL,
  `amount` float NOT NULL,
  `remarks` text NOT NULL,
  `user_id` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `running_balance`
--

INSERT INTO `running_balance` (`id`, `balance_type`, `category_id`, `amount`, `remarks`, `user_id`, `date_created`, `date_updated`) VALUES
(1, 1, 1, 30000, '&lt;p&gt;Sample entry&lt;/p&gt;', '1', '2024-07-30 11:31:03', NULL),
(3, 1, 5, 1500, '&lt;p&gt;test&lt;/p&gt;', '1', '2024-05-06 11:33:29', NULL),
(4, 1, 5, 1500, '&lt;p&gt;test&lt;/p&gt;', '1', '2024-05-06 11:33:56', NULL),
(5, 1, 5, 1500, '&lt;p&gt;test&lt;/p&gt;', '1', '2024-05-06 11:34:17', NULL),
(6, 1, 5, 1500, '&lt;p&gt;test&lt;/p&gt;', '1', '2024-05-06 11:34:44', NULL),
(7, 1, 1, 2500, '&lt;p&gt;test&lt;/p&gt;', '1', '2024-05-06 11:36:32', NULL),
(12, 2, 1, 2500, '&lt;p&gt;Sample expense&lt;/p&gt;', '1', '2024-05-06 13:07:34', NULL),
(13, 1, 1, 2555, '&lt;p&gt;test&lt;/p&gt;', '1', '2024-05-06 13:17:32', NULL),
(14, 2, 1, 2000, '&lt;p&gt;Sample expense&lt;/p&gt;', '1', '2024-05-06 13:36:10', NULL),
(15, 1, 3, 5000, '&lt;p&gt;Sample&lt;/p&gt;', '1', '2024-05-06 14:47:13', NULL),
(16, 1, 4, 3000, '&lt;p&gt;Test 103&lt;/p&gt;', '1', '2024-05-06 14:47:28', NULL),
(17, 1, 2, 2000, '&lt;p&gt;Test 103&lt;/p&gt;', '1', '2024-05-06 14:47:46', NULL),
(18, 1, 2, 3500, '&lt;p&gt;Test 106&lt;/p&gt;', '1', '2024-05-06 14:48:03', NULL),
(20, 2, 2, 800, '&lt;p&gt;Expense for Maintenance 105&lt;/p&gt;', '1', '2024-05-06 14:51:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'Fitness Tracker System'),
(6, 'short_name', 'Fitness Tracker'),
(11, 'logo', 'uploads/Fitness_Tracker');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Norhan', 'Macmod', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/Norhan123', NULL, 1, '2024-05-06 14:02:37', '2024-05-06 09:55:07'),
(4, 'Najar', 'Najar', 'admin', '1254737c076cf867dc53d60a0364f38e', NULL, NULL, 0, '2024-05-06 14:02:37', '2024-05-06 09:55:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `running_balance`
--
ALTER TABLE `running_balance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `running_balance`
--
ALTER TABLE `running_balance`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `running_balance`
--
ALTER TABLE `running_balance`
  ADD CONSTRAINT `running_balance_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;
